<?php
if(!empty($_POST['sub'])){
$name = $_POST['name'];
$project = $_POST['transport-type'];
$email = $_POST['subject'];
$phone =$_POST['message'];

         $to = "contactus@codefactory.in,codefactory000@gmail.com";
         $subject = "Marwa Movers orders : $name";
         
         $message = "<b>Hi Marwa Movers</b>";
         $message .= "<p>You have received a new registration from  Marwa Movers  page, please find the details as follows</p>";
         $message .= "<p>Name : $name</p>";
         $message .= "<p>Education : $project</p>";
         $message .= "<p>Email Id : $email</p>";
         $message .= "<p>Phone Number : $phone</p>";
         

         
         $header = "From:noreply@codefactory.in \r\n";
         $header .= "Cc:sherazeem@gmail.com \r\n";
         $header .= "MIME-Version: 1.0\r\n";
         $header .= "Content-type: text/html\r\n";
         
         $retval = mail ($to,$subject,$message,$header);
         
         if( $retval == true ) {
            echo  "
            <script type=\"text/javascript\">
            alert('Thank you for registering us..We will reply you shortly..!');
            </script>
        ";
         }else {
            echo "Mail could not be sent...";
         }
    }
?>



<?php include'header.php';?>
<div class="page-content"> 

			<!-- Contact -->
			<section class="iframe-section">
				<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3315.0085753561057!2d-117.92116288436817!3d33.812091780671935!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80dcd7d12b3b5e6b%3A0x2ef62f8418225cfa!2sDisneyland+Park!5e0!3m2!1sen!2sin!4v1542193458866"></iframe>
			</section>
			<section>
				<div class="container"> 
					<div class="contact-box"> 
						<div class="row">
							<div class="col-md-4">
								<div class="pbminfotech-ihbox-style-6">
									<div class="pbminfotech-ihbox-inner">
										<div class="pbminfotech-ihbox-icon">
											<div class="pbminfotech-ihbox-icon-wrapper">
												<i class="themifyicon ti-location-pin"></i>
											</div>
										</div>
										<div class="pbminfotech-ihbox-contents">
											<div class="pbminfotech-vc_general pbminfotech-vc_cta3">
												<div class="pbminfotech-vc_cta3_content-container">
													<div class="pbminfotech-vc_cta3-content">
														<div class="pbminfotech-vc_cta3-content-header pbminfotech-wrap">
															<div class="pbminfotech-vc_cta3-headers pbminfotech-wrap-cell">
																<h2 class="pbminfotech-custom-heading ">Our Address</h2>
															</div>
														</div>
													</div>
												</div>
											</div>
											<div class="pbminfotech-cta3-content-wrapper">2946 Angus Road, NY</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-md-4">
								<div class="pbminfotech-ihbox-style-6">
									<div class="pbminfotech-ihbox-inner">
										<div class="pbminfotech-ihbox-icon">
											<div class="pbminfotech-ihbox-icon-wrapper">
												<i class="themifyicon ti-headphone"></i>
											</div>
										</div>
										<div class="pbminfotech-ihbox-contents">
											<div class="pbminfotech-vc_general pbminfotech-vc_cta3">
												<div class="pbminfotech-vc_cta3_content-container">
													<div class="pbminfotech-vc_cta3-content">
														<div class="pbminfotech-vc_cta3-content-header pbminfotech-wrap">
															<div class="pbminfotech-vc_cta3-headers pbminfotech-wrap-cell">
																<h2 class="pbminfotech-custom-heading ">Phone Number</h2>
															</div>
														</div>
													</div>
												</div>
											</div>
											<div class="pbminfotech-cta3-content-wrapper">+31 123 456 7890 – Office</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-md-4">
								<div class="pbminfotech-ihbox-style-6">
									<div class="pbminfotech-ihbox-inner">
										<div class="pbminfotech-ihbox-icon">
											<div class="pbminfotech-ihbox-icon-wrapper">
												<i class="themifyicon ti-email"></i>
											</div>
										</div>
										<div class="pbminfotech-ihbox-contents">
											<div class="pbminfotech-vc_general pbminfotech-vc_cta3">
												<div class="pbminfotech-vc_cta3_content-container">
													<div class="pbminfotech-vc_cta3-content">
														<div class="pbminfotech-vc_cta3-content-header pbminfotech-wrap">
															<div class="pbminfotech-vc_cta3-headers pbminfotech-wrap-cell">
																<h2 class="pbminfotech-custom-heading ">Email Address</h2>
															</div>
														</div>
													</div>
												</div>
											</div>
											<div class="pbminfotech-cta3-content-wrapper"><a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="15767a7b61747661557c7b71606661767a3b7961713b767a78">[email&#160;protected]</a></div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-2"></div>
						<div class="col-md-8">
							<div class="contact-form">
								<div class="pbmit-heading-subheading text-center">
									<h4 class="pbmit-subtitle">CONTACT US</h4>
									<h2 class="pbmit-title">Drop us a line</h2>
								</div>
								<form method="post" id="contact-form" action="#">
									<div class="row"> 
										<div class="col-md-12">
											<input type="text" name="name" class="form-control" placeholder="Your Name" required>
										</div>
										<div class="col-md-6">
											<input type="text" name="transport-type" class="form-control" placeholder="Transport Type" required>
										</div>
										<div class="col-md-6">
											<input type="text" name="subject" class="form-control" placeholder="Subject" required>
										</div>
										<div class="col-md-12">
											<textarea name="message" cols="40" rows="5" class="form-control" placeholder="Message" required></textarea>
										</div>
										<div class="col-md-12">
											<button type="submit" class="pbmit-btn" name="sub">
												<i class="form-btn-loader fa fa-circle-o-notch fa-spin fa-fw margin-bottom d-none"></i>
												Send Message
											</button>
										</div>
										<div class="col-md-12 col-lg-12 message-status"></div>
									</div>
								</form>
							</div>
						</div>
						<div class="col-md-2"></div>
					</div>
				</div>
			</section>
			<!-- Contact End -->

		</div>
        <?php include'footer.php';?>