<?php include'header.php';?>
<div class="pbmit-title-bar-wrapper">
            <div class="container">
               <div class="pbmit-title-bar-content">
                  <div class="pbmit-title-bar-content-inner">
                     <div class="pbmit-tbar">
                        <div class="pbmit-tbar-inner container">
                           <h1 class="pbmit-tbar-title">About Us</h1>
                        </div>
                     </div>
                     <div class="pbmit-breadcrumb">
                        <div class="pbmit-breadcrumb-inner">
                           <span><a title="" href="#" class="home"><span>Marwa Movers</span></a></span>
                           <span class="sep">-</span>
                           <span><span class="post-root post post-post current-item">About Us</span></span>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <!-- Title Bar End-->


         <!-- Page Content -->
         <div class="page-content">  

			<!-- About Us Start -->
			<section class="section-md">
				<div class="container">
					<div class="row">
						<div class="col-md-6">
							<div class="pbmit-heading-subheading-style-1">
								<h4 class="pbmit-subtitle">OUR COMPANY</h4>
								<h2 class="pbmit-title">We are a UAE based top <strong>Marwa Mover company</strong></h2>
							</div>
							<p>As we already mentioned that safety is the most top priority in our sector. We ensure you, the timely and pricesely the most affordable delivery of your valuable goods without any scratches and damages.</p>
							<div class="about-us-left-img">
								<img src="<?php $baseurl="C:\xampp\htdocs\packer"?>New/about1.jpg" class="img-fluid w-100" alt="">
							</div>
						</div>
						<div class="col-md-6">
							<div class="about-us-right-box">
								<img src="<?php $baseurl="C:\xampp\htdocs\packer"?>New/about.jfif" class="img-fluid w-100" alt="">
								<h5>What We do</h5>
								<div class="row">
									<div class="col-md-6">
										<ul class="list-group list-group-one list-group-borderless">
											<li class="list-group-item">
												<i class="fa fa-check"></i>These Happy Days are yours
											</li>
											<li class="list-group-item">
												<i class="fa fa-check"></i>Why do we always come.
											</li>
											<li class="list-group-item">
												<i class="fa fa-check"></i>There ain't nothin' wrong with .
											</li>
										</ul>
									</div>	
									<div class="col-md-6">
										<ul class="list-group list-group-one list-group-borderless">
											<li class="list-group-item">
												<i class="fa fa-check"></i>These Happy Days are yours
											</li>
											<li class="list-group-item">
												<i class="fa fa-check"></i>Why do we always come.
											</li>
											<li class="list-group-item">
												<i class="fa fa-check"></i>There ain't nothin' wrong with .
											</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
			<!-- About Us End -->

			<!-- Counter Start  
			<section class="about-counters-numbers">
				<div class="container">
					<div class="pbmit-heading-subheading-style-1 text-center">
						<h4 class="pbmit-subtitle">fun facts</h4>
						<h2 class="pbmit-title">Counters Numbers <strong> Speak</strong></h2>
					</div>
					<div class="about-counters-box">
						<div class="row">
							<div class="col-md-4">
								<div class="pbminfotech-fidbox-style-3">
									<div class="pbminfotech-fld-contents">
										<div class="pbminfotech-ihbox-icon pbminfotech-large-icon pbminfotech-icon-skincolor">
											<div class="pbminfotech-sbox-icon-wrapper">
												<i class="pbmit-moversco-business-icon pbmit-moversco-business-icon-delivery-truck"></i>
											</div>
										</div>
										<div class="pbminfotech-fid-inner">
											<span data-appear-animation="animateDigits" data-from="0" data-to="750" data-interval="5" class="numinate">750</span>
										</div>
										<h3 class="pbminfotech-fid-title">
											<span>Customer Choose Company Movers<br></span>
										</h3>
									</div>
								</div>
							</div>
							<div class="col-md-4">
								<div class="pbminfotech-fidbox-style-3 about-fidbox-style">
									<div class="pbminfotech-fld-contents">
										<div class="pbminfotech-ihbox-icon pbminfotech-large-icon pbminfotech-icon-skincolor">
											<div class="pbminfotech-sbox-icon-wrapper">
												<i class="pbmit-moversco-business-icon pbmit-moversco-business-icon-box"></i>
											</div>
										</div>
										<div class="pbminfotech-fid-inner">
											<span data-appear-animation="animateDigits" data-from="0" data-to="870" data-interval="5" class="numinate">870</span>
										</div>
										<h3 class="pbminfotech-fid-title">
											<span>Boxes are Successfully Moved<br></span>
										</h3>
									</div>
								</div>
							</div>
							<div class="col-md-4">
								<div class="pbminfotech-fidbox-style-3">
									<div class="pbminfotech-fld-contents">
										<div class="pbminfotech-ihbox-icon pbminfotech-large-icon pbminfotech-icon-skincolor">
											<div class="pbminfotech-sbox-icon-wrapper">
												<i class="pbmit-moversco-business-icon pbmit-moversco-business-icon-like"></i>
											</div>
										</div>
										<div class="pbminfotech-fid-inner">
											<span data-appear-animation="animateDigits" data-from="0" data-to="320" data-interval="5" class="numinate">320</span>
										</div>
										<h3 class="pbminfotech-fid-title">
											<span>Customers are Satisfied with our Service<br></span>
										</h3>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
            <!-- Counter End --> 

			<!-- Testimonial Start 
			<section class="video-section-one">
				<div class="container">
					<div class="row">
						<div class="col-md-6">
							<div class="testimonial-one-bg">
								<div class="pbmit-heading-subheading-style-1 text-white">
									<h4 class="pbmit-subtitle">OUR CLIENTS SAY</h4>
									<h2 class="pbmit-title">We Love Our Clients <br> And <strong>They Love Us</strong></h2>
								</div>
								<div class="swiper-slider"  data-autoplay="true" data-dots="true" data-arrows="false"  data-columns="1" data-margin="30" data-effect="slide">
									<div class="swiper-wrapper">
										<div class="swiper-slide">                           
											<!-- Slide1 
											<article class="pbminfotech-testimonialbox-style-1">
												<div class="pbminfotech-post-item">
													<div class="pbminfotech-box-content">
														<div class="pbminfotech-box-desc">
															<blockquote class="pbminfotech-testimonial-text">Long established fact that a reader will be distracted by the readable content of a page when looking at it's layout. The point of using Lorem Ipsum</blockquote>
														</div>
														<div class="pbminfotech-box-author">
															<div class="pbminfotech-box-title">
																<h3 class="pbminfotech-author-name">Victoria Porter</h3>
																<span class="pbminfotech-box-footer">Customer</span>
															</div>
														</div>
													</div>
												</div>
											</article>
										</div>
										<div class="swiper-slide">                           
											<!-- Slide2 --
											<article class="pbminfotech-testimonialbox-style-1">
												<div class="pbminfotech-post-item">
													<div class="pbminfotech-box-content">
														<div class="pbminfotech-box-desc">
															<blockquote class="pbminfotech-testimonial-text">Long established fact that a reader will be distracted by the readable content of a page when looking at it's layout. The point of using Lorem Ipsum</blockquote>
														</div>
														<div class="pbminfotech-box-author">
															<div class="pbminfotech-box-title">
																<h3 class="pbminfotech-author-name">John Smith</h3>
																<span class="pbminfotech-box-footer">Building Owner </span>
															</div>
														</div>
													</div>
												</div>
											</article>
										</div>
										<div class="swiper-slide">                           
											<!-- Slide3 --
											<article class="pbminfotech-testimonialbox-style-1">
												<div class="pbminfotech-post-item">
													<div class="pbminfotech-box-content">
														<div class="pbminfotech-box-desc">
															<blockquote class="pbminfotech-testimonial-text">Long established fact that a reader will be distracted by the readable content of a page when looking at it's layout. The point of using Lorem Ipsum</blockquote>
														</div>
														<div class="pbminfotech-box-author">
															<div class="pbminfotech-box-title">
																<h3 class="pbminfotech-author-name">Allien John</h3>
																<span class="pbminfotech-box-footer">Customer</span>
															</div>
														</div>
													</div>
												</div>
											</article>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-6">
							<div class="video-one-button-bg">
								<div class="video-one-play-button">
									<span><i class="themifyicon ti-control-play"></i></span>
									<a class="pbmin-lightbox-video" href="https://www.youtube.com/watch?v=g-D0PE2XotQ"></a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
            <!-- Testimonial End -->

            <!-- Team Start --
            <section class="team-section-one team-bg-color">
				<div class="container"> 
					<div class="pbmit-heading-subheading-style-1 text-center">
						<h4 class="pbmit-subtitle">OUR TEAM</h4>
						<h2 class="pbmit-title">Meet our <strong> Professionals</strong></h2>
					</div>
					<div class="row">
						<div class="col-sm-6 col-lg-3">
							<article class="pbminfotech-teambox-style-2">
								<div class="pbminfotech-post-item">
									<span class="pbminfotech-item-thumbnail">
										<span class="pbminfotech-item-thumbnail-inner">
											<img src="images/homepage-1/team/team-01-new.jpg" class="img-fluid" alt="">
										</span>
									</span>		
									<div class="pbminfotech-box-content">
										<div class="pbminfotech-box-content-inner">
											<div class="pbminfotech-pf-box-title">
												<div class="pbminfotech-box-title">
													<h4><a href="team-details.html">Micheal Wagou</a></h4>
												</div>
											</div>
											<div class="pbminfotech-box-team-position">Delivery Boy</div>
											<div class="pbminfotech-teambox-social-links">
												<div class="pbminfotech-team-social-links-wrapper">
													<ul class="pbminfotech-team-social-links">
														<li>
															<a href="#" target="_blank" class="pbminfotech-team-social-facebook">
																<i class="pbmit-base-icon-facebook"></i>
																<span class="pbminfotech-hide">Facebook</span>
															</a>
														</li>
														<li>
															<a href="#" target="_blank" class="pbminfotech-team-social-twitter">
																<i class="pbmit-base-icon-twitter"></i>
																<span class="pbminfotech-hide">Twitter</span>
															</a>
														</li>
														<li>
															<a href="#" target="_blank" class="pbminfotech-team-social-google">
																<i class="pbmit-base-icon-gplus"></i>
																<span class="pbminfotech-hide">Google+</span>
															</a>
														</li>
														<li>
															<a href="#" target="_blank" class="pbminfotech-team-social-linkedin">
																<i class="pbmit-base-icon-linkedin"></i>
																<span class="pbminfotech-hide">LinkedIn</span>
															</a>
														</li>
													</ul> 
												</div>				
											</div>
										</div>
									</div>
								</div>
							</article>
						</div>
						<div class="col-sm-6 col-lg-3">
							<article class="pbminfotech-teambox-style-2">
								<div class="pbminfotech-post-item">
									<span class="pbminfotech-item-thumbnail">
										<span class="pbminfotech-item-thumbnail-inner">
											<img src="images/homepage-1/team/team-02-new.jpg" class="img-fluid" alt="">
										</span>
									</span>		
									<div class="pbminfotech-box-content">
										<div class="pbminfotech-box-content-inner">
											<div class="pbminfotech-pf-box-title">
												<div class="pbminfotech-box-title">
													<h4><a href="team-details.html">Alex Mitchell</a></h4>
												</div>
											</div>
											<div class="pbminfotech-box-team-position">Driver</div>
											<div class="pbminfotech-teambox-social-links">
												<div class="pbminfotech-team-social-links-wrapper">
													<ul class="pbminfotech-team-social-links">
														<li>
															<a href="#" target="_blank" class="pbminfotech-team-social-facebook">
																<i class="pbmit-base-icon-facebook"></i>
																<span class="pbminfotech-hide">Facebook</span>
															</a>
														</li>
														<li>
															<a href="#" target="_blank" class="pbminfotech-team-social-twitter">
																<i class="pbmit-base-icon-twitter"></i>
																<span class="pbminfotech-hide">Twitter</span>
															</a>
														</li>
														<li>
															<a href="#" target="_blank" class="pbminfotech-team-social-google">
																<i class="pbmit-base-icon-gplus"></i>
																<span class="pbminfotech-hide">Google+</span>
															</a>
														</li>
														<li>
															<a href="#" target="_blank" class="pbminfotech-team-social-linkedin">
																<i class="pbmit-base-icon-linkedin"></i>
																<span class="pbminfotech-hide">LinkedIn</span>
															</a>
														</li>
													</ul> 
												</div>				
											</div>
										</div>
									</div>
								</div>
							</article>
						</div>
						<div class="col-sm-6 col-lg-3">
							<article class="pbminfotech-teambox-style-2">
								<div class="pbminfotech-post-item">
									<span class="pbminfotech-item-thumbnail">
										<span class="pbminfotech-item-thumbnail-inner">
											<img src="images/homepage-1/team/team-03-new.jpg" class="img-fluid" alt="">
										</span>
									</span>		
									<div class="pbminfotech-box-content">
										<div class="pbminfotech-box-content-inner">
											<div class="pbminfotech-pf-box-title">
												<div class="pbminfotech-box-title">
													<h4><a href="team-details.html">Margaret Anderson</a></h4>
												</div>
											</div>
											<div class="pbminfotech-box-team-position">Manager</div>
											<div class="pbminfotech-teambox-social-links">
												<div class="pbminfotech-team-social-links-wrapper">
													<ul class="pbminfotech-team-social-links">
														<li>
															<a href="#" target="_blank" class="pbminfotech-team-social-facebook">
																<i class="pbmit-base-icon-facebook"></i>
																<span class="pbminfotech-hide">Facebook</span>
															</a>
														</li>
														<li>
															<a href="#" target="_blank" class="pbminfotech-team-social-twitter">
																<i class="pbmit-base-icon-twitter"></i>
																<span class="pbminfotech-hide">Twitter</span>
															</a>
														</li>
														<li>
															<a href="#" target="_blank" class="pbminfotech-team-social-google">
																<i class="pbmit-base-icon-gplus"></i>
																<span class="pbminfotech-hide">Google+</span>
															</a>
														</li>
														<li>
															<a href="#" target="_blank" class="pbminfotech-team-social-linkedin">
																<i class="pbmit-base-icon-linkedin"></i>
																<span class="pbminfotech-hide">LinkedIn</span>
															</a>
														</li>
													</ul> 
												</div>				
											</div>
										</div>
									</div>
								</div>
							</article>
						</div>
						<div class="col-sm-6 col-lg-3">
							<article class="pbminfotech-teambox-style-2">
								<div class="pbminfotech-post-item">
									<span class="pbminfotech-item-thumbnail">
										<span class="pbminfotech-item-thumbnail-inner">
											<img src="images/homepage-1/team/team-04-new.jpg" class="img-fluid" alt="">
										</span>
									</span>		
									<div class="pbminfotech-box-content">
										<div class="pbminfotech-box-content-inner">
											<div class="pbminfotech-pf-box-title">
												<div class="pbminfotech-box-title">
													<h4><a href="team-details.html">John Harris</a></h4>
												</div>
											</div>
											<div class="pbminfotech-box-team-position">Delivery Boy</div>
											<div class="pbminfotech-teambox-social-links">
												<div class="pbminfotech-team-social-links-wrapper">
													<ul class="pbminfotech-team-social-links">
														<li>
															<a href="#" target="_blank" class="pbminfotech-team-social-facebook">
																<i class="pbmit-base-icon-facebook"></i>
																<span class="pbminfotech-hide">Facebook</span>
															</a>
														</li>
														<li>
															<a href="#" target="_blank" class="pbminfotech-team-social-twitter">
																<i class="pbmit-base-icon-twitter"></i>
																<span class="pbminfotech-hide">Twitter</span>
															</a>
														</li>
														<li>
															<a href="#" target="_blank" class="pbminfotech-team-social-google">
																<i class="pbmit-base-icon-gplus"></i>
																<span class="pbminfotech-hide">Google+</span>
															</a>
														</li>
														<li>
															<a href="#" target="_blank" class="pbminfotech-team-social-linkedin">
																<i class="pbmit-base-icon-linkedin"></i>
																<span class="pbminfotech-hide">LinkedIn</span>
															</a>
														</li>
													</ul> 
												</div>				
											</div>
										</div>
									</div>
								</div>
							</article>
						</div>
					</div>
				</div>
			</section>-->
            <!-- Team End -->

         </div>
         <?php include'footer.php';?>