<?php include'header.php';?>
		<div class="pbmit-title-bar-wrapper">
			<div class="container">
				<div class="pbmit-title-bar-content">
					<div class="pbmit-title-bar-content-inner">
						<div class="pbmit-tbar">
							<div class="pbmit-tbar-inner container">
								<h1 class="pbmit-tbar-title">Gallery</h1>
							</div>
						</div>
						<div class="pbmit-breadcrumb">
							<div class="pbmit-breadcrumb-inner">
								<span><a title="" href="#" class="home"><span>Marwa Movers</span></a></span>
								<span class="sep">-</span>
								<span><span class="post-root post post-post current-item">Gallery</span></span>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- Title Bar End-->

		<!-- Page Content -->
		<div class="page-content Project-Style-2"> 

			<!-- Portfolio Style 2 -->
			<section class="section-md">
				<div class="container">
					<div class="row">
						<div class="col-md-6 col-lg-4">
							<article class="pbminfotech-portfoliobox-style-2">
								<div class="pbminfotech-post-item">
									<span class="pbminfotech-item-thumbnail">
										<span class="pbminfotech-item-thumbnail-inner">
											<img src="<?php $baseurl="C:\xampp\htdocs\packer"?>New/new/gallery1.jpg" class="img-fluid" alt="">
										</span>
									</span>		
									<div class="pbminfotech-box-content pbminfotech-overlay">
										<div class="pbminfotech-box-content-inner">
											<div class="pbminfotech-pf-box-title">
												<h3><a href="projects-single.html">Office Removals</a></h3>
											</div>
											<div class="pbminfotech-view-details">
												<a href="#">Details</a>				
											</div>
										</div>
									</div>
								</div>
							</article>
						</div>
						<div class="col-md-6 col-lg-4">
							<article class="pbminfotech-portfoliobox-style-2">
								<div class="pbminfotech-post-item">
									<span class="pbminfotech-item-thumbnail">
										<span class="pbminfotech-item-thumbnail-inner">
											<img src="<?php $baseurl="C:\xampp\htdocs\packer"?>New/new/gallery2.jpg" class="img-fluid" alt="">
										</span>
									</span>		
									<div class="pbminfotech-box-content pbminfotech-overlay">
										<div class="pbminfotech-box-content-inner">
											<div class="pbminfotech-pf-box-title">
												<h3><a href="projects-single.html">Overseas Moving</a></h3>
											</div>
											<div class="pbminfotech-view-details">
												<a href="#">Details</a>				
											</div>
										</div>
									</div>
								</div>
							</article>
						</div>
						<div class="col-md-6 col-lg-4">
							<article class="pbminfotech-portfoliobox-style-2">
								<div class="pbminfotech-post-item">
									<span class="pbminfotech-item-thumbnail">
										<span class="pbminfotech-item-thumbnail-inner">
											<img src="<?php $baseurl="C:\xampp\htdocs\packer"?>New/new/gallery3.jpg" class="img-fluid" alt="">
										</span>
									</span>		
									<div class="pbminfotech-box-content pbminfotech-overlay">
										<div class="pbminfotech-box-content-inner">
											<div class="pbminfotech-pf-box-title">
												<h3><a href="projects-single.html">Warehousing Solutions</a></h3>
											</div>
											<div class="pbminfotech-view-details">
												<a href="#">Details</a>				
											</div>
										</div>
									</div>
								</div>
							</article>
						</div>
						<div class="col-md-6 col-lg-4">
							<article class="pbminfotech-portfoliobox-style-2">
								<div class="pbminfotech-post-item">
									<span class="pbminfotech-item-thumbnail">
										<span class="pbminfotech-item-thumbnail-inner">
											<img src="<?php $baseurl="C:\xampp\htdocs\packer"?>New/new/gallery4.jpg" class="img-fluid" alt="">
										</span>
									</span>		
									<div class="pbminfotech-box-content pbminfotech-overlay">
										<div class="pbminfotech-box-content-inner">
											<div class="pbminfotech-pf-box-title">
												<h3><a href="projects-single.html">Moving Interstate</a></h3>
											</div>
											<div class="pbminfotech-view-details">
												<a href="#">Details</a>				
											</div>
										</div>
									</div>
								</div>
							</article>
						</div>
						<div class="col-md-6 col-lg-4">
							<article class="pbminfotech-portfoliobox-style-2">
								<div class="pbminfotech-post-item">
									<span class="pbminfotech-item-thumbnail">
										<span class="pbminfotech-item-thumbnail-inner">
											<img src="<?php $baseurl="C:\xampp\htdocs\packer"?>New/new/gallery5.jpg" class="img-fluid" alt="">
										</span>
									</span>		
									<div class="pbminfotech-box-content pbminfotech-overlay">
										<div class="pbminfotech-box-content-inner">
											<div class="pbminfotech-pf-box-title">
												<h3><a href="projects-single.html">Office Furniture Moving</a></h3>
											</div>
											<div class="pbminfotech-view-details">
												<a href="#">Details</a>				
											</div>
										</div>
									</div>
								</div>
							</article>
						</div>
						<div class="col-md-6 col-lg-4">
							<article class="pbminfotech-portfoliobox-style-2">
								<div class="pbminfotech-post-item">
									<span class="pbminfotech-item-thumbnail">
										<span class="pbminfotech-item-thumbnail-inner">
											<img src="<?php $baseurl="C:\xampp\htdocs\packer"?>New/new/gallery6.jpg" class="img-fluid" alt="">
										</span>
									</span>		
									<div class="pbminfotech-box-content pbminfotech-overlay">
										<div class="pbminfotech-box-content-inner">
											<div class="pbminfotech-pf-box-title">
												<h3><a href="projects-single.html">Living Room</a></h3>
											</div>
											<div class="pbminfotech-view-details">
												<a href="#">Details</a>				
											</div>
										</div>
									</div>
								</div>
							</article>
						</div>
						<div class="col-md-6 col-lg-4">
							<article class="pbminfotech-portfoliobox-style-2">
								<div class="pbminfotech-post-item">
									<span class="pbminfotech-item-thumbnail">
										<span class="pbminfotech-item-thumbnail-inner">
											<img src="<?php $baseurl="C:\xampp\htdocs\packer"?>New/new/gallery7.jpg" class="img-fluid" alt="">
										</span>
									</span>		
									<div class="pbminfotech-box-content pbminfotech-overlay">
										<div class="pbminfotech-box-content-inner">
											<div class="pbminfotech-pf-box-title">
												<h3><a href="projects-single.html">Beautiful House</a></h3>
											</div>
											<div class="pbminfotech-view-details">
												<a href="#">Details</a>				
											</div>
										</div>
									</div>
								</div>
							</article>
						</div>
						<div class="col-md-6 col-lg-4">
							<article class="pbminfotech-portfoliobox-style-2">
								<div class="pbminfotech-post-item">
									<span class="pbminfotech-item-thumbnail">
										<span class="pbminfotech-item-thumbnail-inner">
											<img src="<?php $baseurl="C:\xampp\htdocs\packer"?>New/new/gallery8.jpg" class="img-fluid" alt="">
										</span>
									</span>		
									<div class="pbminfotech-box-content pbminfotech-overlay">
										<div class="pbminfotech-box-content-inner">
											<div class="pbminfotech-pf-box-title">
												<h3><a href="projects-single.html">Fashion Shop</a></h3>
											</div>
											<div class="pbminfotech-view-details">
												<a href="#">Details</a>				
											</div>
										</div>
									</div>
								</div>
							</article>
						</div>
						<div class="col-md-6 col-lg-4">
							<article class="pbminfotech-portfoliobox-style-2">
								<div class="pbminfotech-post-item">
									<span class="pbminfotech-item-thumbnail">
										<span class="pbminfotech-item-thumbnail-inner">
											<img src="<?php $baseurl="C:\xampp\htdocs\packer"?>New/new/gallery9.jpg" class="img-fluid" alt="">
										</span>
									</span>		
									<div class="pbminfotech-box-content pbminfotech-overlay">
										<div class="pbminfotech-box-content-inner">
											<div class="pbminfotech-pf-box-title">
												<h3><a href="projects-single.html">Surface Cleaning</a></h3>
											</div>
											<div class="pbminfotech-view-details">
												<a href="#">Details</a>				
											</div>
										</div>
									</div>
								</div>
							</article>
						</div>
						<div class="col-md-6 col-lg-4">
							<article class="pbminfotech-portfoliobox-style-2">
								<div class="pbminfotech-post-item">
									<span class="pbminfotech-item-thumbnail">
										<span class="pbminfotech-item-thumbnail-inner">
											<img src="<?php $baseurl="C:\xampp\htdocs\packer"?>New/new/gallery10.jpg" class="img-fluid" alt="">
										</span>
									</span>		
									<div class="pbminfotech-box-content pbminfotech-overlay">
										<div class="pbminfotech-box-content-inner">
											<div class="pbminfotech-pf-box-title">
												<h3><a href="projects-single.html">Residential Movers</a></h3>
											</div>
											<div class="pbminfotech-view-details">
												<a href="#">Details</a>				
											</div>
										</div>
									</div>
								</div>
							</article>
						</div>
						<div class="col-md-6 col-lg-4">
							<article class="pbminfotech-portfoliobox-style-2">
								<div class="pbminfotech-post-item">
									<span class="pbminfotech-item-thumbnail">
										<span class="pbminfotech-item-thumbnail-inner">
											<img src="<?php $baseurl="C:\xampp\htdocs\packer"?>New/new/gallery11.jpg" class="img-fluid" alt="">
										</span>
									</span>		
									<div class="pbminfotech-box-content pbminfotech-overlay">
										<div class="pbminfotech-box-content-inner">
											<div class="pbminfotech-pf-box-title">
												<h3><a href="projects-single.html">Cultural House</a></h3>
											</div>
											<div class="pbminfotech-view-details">
												<a href="#">Details</a>				
											</div>
										</div>
									</div>
								</div>
							</article>
						</div>
						<div class="col-md-6 col-lg-4">
							<article class="pbminfotech-portfoliobox-style-2">
								<div class="pbminfotech-post-item">
									<span class="pbminfotech-item-thumbnail">
										<span class="pbminfotech-item-thumbnail-inner">
											<img src="<?php $baseurl="C:\xampp\htdocs\packer"?>New/new/gallery12.jfif" class="img-fluid" alt="">
										</span>
									</span>		
									<div class="pbminfotech-box-content pbminfotech-overlay">
										<div class="pbminfotech-box-content-inner">
											<div class="pbminfotech-pf-box-title">
												<h3><a href="projects-single.html">Organic Synthesis</a></h3>
											</div>
											<div class="pbminfotech-view-details">
												<a href="#">Details</a>				
											</div>
										</div>
									</div>
								</div>
							</article>
						</div>
					</div>
				</div>
			</section>
			<!-- Portfolio Style 2 End -->

		</div>
		<?php include'footer.php';?>