
<!doctype html>
<html class="no-js" lang="en">
   <head>
    <?php $baseurl="C:\xampp\htdocs\packer"?>
      <meta charset="utf-8">
      <meta http-equiv="x-ua-compatible" content="ie=edge">
      <title>Marwa Movers InfosStack – Movers, Relocation, Transport & Packers HTML Template</title>
      <meta name="robots" content="noindex, follow">
      <meta name="description" content="">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <!-- Favicon -->
      <link rel="shortcut icon" type="image/x-icon" href="images/favicon.png">
	  

	  <!-- whatsapp-->
	  <script src="https://static.elfsight.com/platform/platform.js" data-use-service-core defer></script>
<div class="elfsight-app-13954d80-69c6-4a65-99bf-df00d6cf73f2"></div>
      <!-- CSS
         ============================================ --> 
      <!-- Bootstrap CSS -->
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <!-- Fontawesome -->
      <link rel="stylesheet" href="css/fontawesome.css">
      <!-- Flaticon -->
      <link rel="stylesheet" href="css/flaticon.css">
	  
      <!-- Base Icons -->
      <link rel="stylesheet" href="css/pbminfotech-base-icons.css"> 
	  
      <!-- Swiper -->
      <link rel="stylesheet" href="css/swiper.min.css">
      <!-- Magnific -->
      <link rel="stylesheet" href="css/magnific-popup.css"> 
      <!-- Shortcode CSS -->
      <link rel="stylesheet" href="css/shortcode.css">
	  <!-- Themify Icons -->
	  <link rel="stylesheet" href="css/themify-icons.css">
	  <!-- AOS -->
	  <link rel="stylesheet" href="css/aos.css">
      <!-- Demo Base CSS -->
      <link rel="stylesheet" href="css/demo-1.css">
      <!-- Base CSS -->
      <link rel="stylesheet" href="css/base.css">
      <!-- Style CSS -->
      <link rel="stylesheet" href="css/style.css">
      <!-- Responsive CSS -->
      <link rel="stylesheet" href="css/responsive.css"> 
      <!-- REVOLUTION STYLE SHEETS -->
      <link rel="stylesheet" type="text/css" href="<?php $baseurl="C:\xampp\htdocs\packer"?>css/rs6.css">
   </head>
   <body>
      <!-- page wrapper -->
      <div class="page-wrapper">

		<!-- Header Main Area -->
		<header class="site-header header-style-2">
			<div class="pre-header">
				<div class="container">
					<div class="site-branding">
						<span class="site-title">
							<a href="index.html">
								<img class="logo-img" src="<?php $baseurl="C:\xampp\htdocs\packer"?>images/pack.png" alt="marwa">
							</a>
						</span>
					</div>
					<div class="pbmit-infostack-right-content">
						<div class="info-widget">
							<div class="info-widget-inner">
								<div class="media-left">
									<div class="icon"> <i class="pbmit-base-icon-phone-call"></i></div>
								</div>
								<div class="media-right">
									<h6>Telephone </h6>
									<h3>+971 50 200 2628 </h3>
								</div>
							</div>
						</div>
						<div class="info-widget">
							<div class="info-widget-inner">
								<div class="media-left">
									<div class="icon"> <i class="pbmit-base-icon-envelope"></i></div>
								</div>
								<div class="media-right">
									<h6>Email Address </h6>
									<h3><a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="ef86818980af8280998a9d9c8c80c18c8082">[email&#160;protected]</a> </h3>
								</div>
							</div>
						</div>
						<div class="pbmit-header-button-w">
							<a href="contact.php" class="pbmit-btn "> Request a quote</a>
						</div>
					</div>
				</div>
			</div>
			<div class="site-header-menu">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<div class="site-navigations">
								<nav class="main-menu navbar-expand-xl navbar-light">
									<div class="navbar-header">
										<!-- Toggle Button --> 
										<button class="navbar-toggler" type="button">
											<i class="pbmit-moversco-icon-bars"></i>
										</button>
									</div>
									<div class="pbmit-mobile-menu-bg"></div>
									<div class="collapse navbar-collapse clearfix show" id="pbmit-menu">
										<div class="pbmit-menu-wrap">
											<ul class="navigation clearfix">
												<li class=" active">
													<a href="index.php">Home</a>
													
												</li>
												<li class="">
													<a href="about.php">About</a>
													
												</li>
												<li class="">
													<a href="gallery.php">gallery</a>
													
												</li>
												<li class="">
													<a href="service.php">Services</a>
													
												</li>
												<li class="">
													<a href="contact.php">contact us</a>
													
												</li>
												<li><a href="contact.php">Request quote</a></li>
											</ul>
										</div>
									</div>
								</nav>
							</div>
							<div class="pbmit-right-box">
								<div class="pbmit-header-search-btn">
									<a href="#"><i class="pbmit-base-icon-search-2"></i></a>
								</div>
								<div class="pbminfotech-social-links-wrapper">
									<ul class="social-icons">
										<li class="pbmit-social-facebook">
											<a class=" tooltip-top" title="Facebook" target="_blank" href="#" data-tooltip="Facebook">
												<i class="pbmit-base-icon-facebook"></i>
											</a>
										</li>
										<li class="pbmit-social-twitter">
											<a class=" tooltip-top" title="Twitter" target="_blank" href="#" data-tooltip="Twitter">
												<i class="pbmit-base-icon-twitter"></i>
											</a>
										</li>
										<li class="pbmit-social-flickr">
											<a class=" tooltip-top" title="Flickr" target="_blank" href="#" data-tooltip="Flickr">
												<i class="pbmit-base-icon-flickr"></i>
											</a>
										</li>
										<li class="pbmit-social-gplus">
											<a class=" tooltip-top" target="_blank" href="#" data-tooltip="Google+">
												<i class="pbmit-base-icon-gplus"></i>
											</a>
										</li>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="pbmit-slider-area">
				<!-- START Homeslider2 REVOLUTION SLIDER 6.5.15 --><p class="rs-p-wp-fix"></p>
				<rs-module-wrap id="rev_slider_2_1_wrapper" data-alias="homeslider2" data-source="gallery" style="visibility:hidden;background:transparent;padding:0;margin:0px auto;margin-top:0;margin-bottom:0;">
					<rs-module id="rev_slider_2_1" data-version="6.5.15">
						<rs-slides>
							<rs-slide style="position: absolute;" data-key="rs-3" data-title="Slide" data-thumb="revolution/images/banner-03.jpg" data-anim="ms:600;" data-in="o:0;" data-out="a:false;">
								<img src=" <?php $baseurl="C:\xampp\htdocs\packer"?>images/banner-03.jpg" alt="" class="rev-slidebg tp-rs-img rs-lazyload" data-lazyload="revolution/images/banner-03.jpg" data-no-retina>
	<!--
								--><rs-layer
									id="slider-2-slide-3-layer-1" 
									class="tp-shape tp-shapewrapper"
									data-type="shape"
									data-rsp_ch="on"
									data-xy="xo:0,0,0,15px;yo:362px,362px,362px,202px;"
									data-text="a:inherit;"
									data-dim="w:431px,431px,431px,304px;h:388px,388px,388px,274px;"
									data-frame_0="y:100%;tp:600;"
									data-frame_0_mask="u:t;y:100%;"
									data-frame_1="tp:600;e:power2.inOut;st:310;sp:1500;sR:310;"
									data-frame_1_mask="u:t;"
									data-frame_999="o:0;tp:600;st:w;sR:7190;"
									style="z-index:5;background-color:#e32222;"
								> 
								</rs-layer><!--

								--><rs-layer
									id="slider-2-slide-3-layer-2" 
									data-type="text"
									data-rsp_ch="on"
									data-xy="xo:35px,35px,35px,40px;yo:400px,400px,400px,234px;"
									data-text="s:45,45,45,32;l:60,60,60,38;fw:800;a:inherit;"
									data-dim="w:359px;"
									data-frame_0="o:1;tp:600;"
									data-frame_0_chars="d:5;y:-100%;o:1;rZ:35deg;"
									data-frame_0_mask="u:t;"
									data-frame_1="tp:600;e:power4.inOut;st:1270;sp:1500;sR:1270;"
									data-frame_1_chars="d:5;"
									data-frame_1_mask="u:t;"
									data-frame_999="o:0;tp:600;st:w;sR:4980;"
									style="z-index:6;font-family:'Nunito Sans';"
								>We Provide Best <br> Moving Service 
								</rs-layer><!--

								--><rs-layer
									id="slider-2-slide-3-layer-3" 
									data-type="text"
									data-color="rgba(255, 255, 255, 0.8)"
									data-rsp_ch="on"
									data-xy="xo:35px;yo:544px;"
									data-text="s:18;l:28;a:inherit;"
									data-dim="w:374px;h:117px;"
									data-frame_0="y:100%;tp:600;"
									data-frame_0_mask="u:t;y:100%;"
									data-frame_1="tp:600;e:power2.inOut;st:2670;sp:1500;sR:2670;"
									data-frame_1_mask="u:t;"
									data-frame_999="o:0;tp:600;st:w;sR:4830;"
									style="z-index:7;font-family:'Open Sans';"
								>We offer marketing and consulting services<br> for companies & businesses working in<br> these industries. 
								</rs-layer><!--

								--><rs-layer
									id="slider-2-slide-3-layer-5" 
									class="rev-btn"
									data-type="button"
									data-color="#313437||#313437||#313437||#0a0a0a"
									data-xy="xo:35px,35px,35px,40px;yo:659px,659px,659px,325px;"
									data-text="s:14;l:30;fw:500;a:inherit;"
									data-rsp_bd="off"
									data-padding="t:10;r:30;b:10;l:30;"
									data-frame_0="tp:600;"
									data-frame_1="tp:600;e:power4.inOut;st:3970;sp:500;sR:3970;"
									data-frame_999="o:0;tp:600;st:w;sR:4530;"
									data-frame_hover="c:#fff;bgc:#313437;boc:#fff;bor:0px,0px,0px,0px;bos:solid;bow:0px,0px,0px,0px;oX:50;oY:50;sp:0;e:none;"
									style="z-index:8;background-color:#ffffff;font-family:'Roboto';cursor:pointer;outline:none;box-shadow:none;box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;"
								>VIEW OUR WORK 
								</rs-layer><!--
	-->						</rs-slide>
							<rs-slide style="position: absolute;" data-key="rs-4" data-title="Slide" data-thumb="revolution/images/banner-04.jpg" data-anim="ms:600;" data-in="o:0;" data-out="a:false;">
								<img src="<?php $baseurl="C:\xampp\htdocs\packer"?>images/banner-04.jpg" alt="" class="rev-slidebg tp-rs-img rs-lazyload" data-lazyload="revolution/images/banner-04.jpg" data-no-retina>
	<!--
								--><rs-layer
									id="slider-2-slide-4-layer-1" 
									class="tp-shape tp-shapewrapper"
									data-type="shape"
									data-rsp_ch="on"
									data-xy="xo:0,0,0,15px;yo:362px,362px,362px,202px;"
									data-text="a:inherit;"
									data-dim="w:431px,431px,431px,304px;h:388px,388px,388px,274px;"
									data-frame_0="y:100%;tp:600;"
									data-frame_0_mask="u:t;y:100%;"
									data-frame_1="tp:600;e:power2.inOut;st:310;sp:1500;sR:310;"
									data-frame_1_mask="u:t;"
									data-frame_999="o:0;tp:600;st:w;sR:7190;"
									style="z-index:5;background-color:#e32222;"
								> 
								</rs-layer><!--

								--><rs-layer
									id="slider-2-slide-4-layer-2" 
									data-type="text"
									data-rsp_ch="on"
									data-xy="xo:35px,35px,35px,40px;yo:400px,400px,400px,234px;"
									data-text="s:45,45,45,32;l:60,60,60,38;fw:800;a:inherit;"
									data-dim="w:359px;"
									data-frame_0="o:1;tp:600;"
									data-frame_0_chars="d:5;y:-100%;o:1;rZ:35deg;"
									data-frame_0_mask="u:t;"
									data-frame_1="tp:600;e:power4.inOut;st:1270;sp:1500;sR:1270;"
									data-frame_1_chars="d:5;"
									data-frame_1_mask="u:t;"
									data-frame_999="o:0;tp:600;st:w;sR:4980;"
									style="z-index:6;font-family:'Nunito Sans';"
								>We Provide Best <br> Moving Service 
								</rs-layer><!--

								--><rs-layer
									id="slider-2-slide-4-layer-3" 
									data-type="text"
									data-color="rgba(255, 255, 255, 0.8)"
									data-rsp_ch="on"
									data-xy="xo:35px;yo:544px;"
									data-text="s:18;l:28;a:inherit;"
									data-dim="w:374px;h:117px;"
									data-frame_0="y:100%;tp:600;"
									data-frame_0_mask="u:t;y:100%;"
									data-frame_1="tp:600;e:power2.inOut;st:2670;sp:1500;sR:2670;"
									data-frame_1_mask="u:t;"
									data-frame_999="o:0;tp:600;st:w;sR:4830;"
									style="z-index:7;font-family:'Open Sans';"
								>We offer marketing and consulting services<br> for companies & businesses working in<br> these industries. 
								</rs-layer><!--

								--><rs-layer
									id="slider-2-slide-4-layer-5" 
									class="rev-btn"
									data-type="button"
									data-color="#0a0a0a"
									data-xy="xo:35px,35px,35px,40px;yo:659px,659px,659px,325px;"
									data-text="s:14;l:30;fw:500;a:inherit;"
									data-rsp_bd="off"
									data-padding="t:10;r:30;b:10;l:30;"
									data-frame_0="tp:600;"
									data-frame_1="tp:600;e:power4.inOut;st:3970;sp:500;sR:3970;"
									data-frame_999="o:0;tp:600;st:w;sR:4530;"
									data-frame_hover="c:#fff;bgc:#313437;boc:#fff;bor:0px,0px,0px,0px;bos:solid;bow:0px,0px,0px,0px;oX:50;oY:50;sp:0;e:none;"
									style="z-index:8;background-color:#ffffff;font-family:'Roboto';cursor:pointer;outline:none;box-shadow:none;box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;"
								>VIEW OUR WORK 
								</rs-layer><!--
	-->						</rs-slide>
						</rs-slides>
					</rs-module>
				</rs-module-wrap>
				<!-- END REVOLUTION SLIDER -->
			</div>
		</header>
		<!-- Header Main Area End Here -->