
<?php include 'header.php';?>
<div class="pbmit-title-bar-wrapper">
			<div class="container">
				<div class="pbmit-title-bar-content">
					<div class="pbmit-title-bar-content-inner">
						<div class="pbmit-tbar">
							<div class="pbmit-tbar-inner container">
								<h1 class="pbmit-tbar-title">Our Services</h1>
							</div>
						</div>
						<div class="pbmit-breadcrumb">
							<div class="pbmit-breadcrumb-inner">
								<span><a title="" href="#" class="home"><span>Marwa Movers</span></a></span>
								<span class="sep">-</span>
								<span class="post-root post post-post current-item">You Can Have A Happy And Stress-Free Moving Experience With Our Relocation Services.

</span>
							</div>
						</div>
					</div>
				</div> 
			</div> 
		</div>
		<!-- Title Bar End-->

		<!-- Page Content -->
		<div class="page-content">   

            <!-- service -->
            <section class="section-md">
				<div class="container">
					<div class="row">
						<div class="col-md-6 col-lg-4">
							<article class="pbminfotech-servicebox-style-1">
								<div class="pbminfotech-post-item">
									<span class="pbminfotech-item-thumbnail">
										<span class="pbminfotech-item-thumbnail-inner">
											<img src="<?php $baseurl="C:\xampp\htdocs\packer"?>New/servic1.jpg" class="img-fluid" alt="">
										</span>
									</span>		
									<div class="pbminfotech-box-content">
										<div class="pbminfotech-box-content-inner">
											<div class="pbminfotech-pf-box-title">
												<div class="pbmit-ihbox-icon">
													<i class="pbmit-moversco-business-icon pbmit-moversco-business-icon-shipping-and-delivery-1"></i>					
												</div>
												<h3>
													<a href="services-details.html">Residential Moves</a>
												</h3>
												<div class="pbminfotech-service-content">
													<p>Extreme attention to detail is the essence of Boo’s unique.</p>
												</div>
												<div class="pbminfotech-box-link">
													<a href="services-details.html">READ MORE</a>
												</div>
											</div>
										</div>
									</div>
								</div>
							</article>
						</div>
						<div class="col-md-6 col-lg-4">
							<article class="pbminfotech-servicebox-style-1">
								<div class="pbminfotech-post-item">
									<span class="pbminfotech-item-thumbnail">
										<span class="pbminfotech-item-thumbnail-inner">
											<img src="<?php $baseurl="C:\xampp\htdocs\packer"?>New/service2.jpg" class="img-fluid" alt="">
										</span>
									</span>		
									<div class="pbminfotech-box-content">
										<div class="pbminfotech-box-content-inner">
											<div class="pbminfotech-pf-box-title">
												<div class="pbmit-ihbox-icon">
													<i class="pbmit-moversco-business-icon pbmit-moversco-business-icon-headset-1"></i>					
												</div>
												<h3>
													<a href="services-details.html">Corporate Relocation</a>
												</h3>
												<div class="pbminfotech-service-content">
													<p>Extreme attention to detail is the essence of Boo’s unique.</p>
												</div>
												<div class="pbminfotech-box-link">
													<a href="services-details.html">READ MORE</a>
												</div>
											</div>
										</div>
									</div>
								</div>
							</article>
						</div>
						<div class="col-md-6 col-lg-4">
							<article class="pbminfotech-servicebox-style-1">
								<div class="pbminfotech-post-item">
									<span class="pbminfotech-item-thumbnail">
										<span class="pbminfotech-item-thumbnail-inner">
											<img src="<?php $baseurl="C:\xampp\htdocs\packer"?>New/service3.jpg" class="img-fluid" alt="">
										</span>
									</span>		
									<div class="pbminfotech-box-content">
										<div class="pbminfotech-box-content-inner">
											<div class="pbminfotech-pf-box-title">
												<div class="pbmit-ihbox-icon">
													<i class="pbmit-moversco-business-icon pbmit-moversco-business-icon-house"></i>					
												</div>
												<h3>
													<a href="services-details.html">Warehousing & Storage</a>
												</h3>
												<div class="pbminfotech-service-content">
													<p>Extreme attention to detail is the essence of Boo’s unique.</p>
												</div>
												<div class="pbminfotech-box-link">
													<a href="services-details.html">READ MORE</a>
												</div>
											</div>
										</div>
									</div>
								</div>
							</article>
						</div>
						<div class="col-md-6 col-lg-4">
							<article class="pbminfotech-servicebox-style-1">
								<div class="pbminfotech-post-item">
									<span class="pbminfotech-item-thumbnail">
										<span class="pbminfotech-item-thumbnail-inner">
											<img src="<?php $baseurl="C:\xampp\htdocs\packer"?>New/service4.jpg" class="img-fluid" alt="">
										</span>
									</span>		
									<div class="pbminfotech-box-content">
										<div class="pbminfotech-box-content-inner">
											<div class="pbminfotech-pf-box-title">
												<div class="pbmit-ihbox-icon">
													<i class="pbmit-moversco-business-icon pbmit-moversco-business-icon-shipping-and-delivery"></i>					
												</div>
												<h3>
													<a href="services-details.html">Commercial Movers</a>
												</h3>
												<div class="pbminfotech-service-content">
													<p>Extreme attention to detail is the essence of Boo’s unique.</p>
												</div>
												<div class="pbminfotech-box-link">
													<a href="services-details.html">READ MORE</a>
												</div>
											</div>
										</div>
									</div>
								</div>
							</article>
						</div>
						<div class="col-md-6 col-lg-4">
							<article class="pbminfotech-servicebox-style-1">
								<div class="pbminfotech-post-item">
									<span class="pbminfotech-item-thumbnail">
										<span class="pbminfotech-item-thumbnail-inner">
											<img src="<?php $baseurl="C:\xampp\htdocs\packer"?>New/service5.jpg" class="img-fluid" alt="">
										</span>
									</span>		
									<div class="pbminfotech-box-content">
										<div class="pbminfotech-box-content-inner">
											<div class="pbminfotech-pf-box-title">
												<div class="pbmit-ihbox-icon">
													<i class="pbmit-moversco-business-icon pbmit-moversco-business-icon-like"></i>					
												</div>
												<h3>
													<a href="services-details.html">Door to Door Service</a>
												</h3>
												<div class="pbminfotech-service-content">
													<p>Extreme attention to detail is the essence of Boo’s unique.</p>
												</div>
												<div class="pbminfotech-box-link">
													<a href="services-details.html">READ MORE</a>
												</div>
											</div>
										</div>
									</div>
								</div>
							</article>
						</div>
						<div class="col-md-6 col-lg-4">
							<article class="pbminfotech-servicebox-style-1">
								<div class="pbminfotech-post-item">
									<span class="pbminfotech-item-thumbnail">
										<span class="pbminfotech-item-thumbnail-inner">
											<img src="<?php $baseurl="C:\xampp\htdocs\packer"?>New/service6.jpg" class="img-fluid" alt="">
										</span>
									</span>		
									<div class="pbminfotech-box-content">
										<div class="pbminfotech-box-content-inner">
											<div class="pbminfotech-pf-box-title">
												<div class="pbmit-ihbox-icon">
													<i class="pbmit-moversco-business-icon pbmit-moversco-business-icon-box"></i>					
												</div>
												<h3>
													<a href="services-details.html">Household Moving</a>
												</h3>
												<div class="pbminfotech-service-content">
													<p>Extreme attention to detail is the essence of Boo’s unique.</p>
												</div>
												<div class="pbminfotech-box-link">
													<a href="services-details.html">READ MORE</a>
												</div>
											</div>
										</div>
									</div>
								</div>
							</article>
						</div>
						<div class="col-md-6 col-lg-4">
							<article class="pbminfotech-servicebox-style-1">
								<div class="pbminfotech-post-item">
									<span class="pbminfotech-item-thumbnail">
										<span class="pbminfotech-item-thumbnail-inner">
											<img src="<?php $baseurl="C:\xampp\htdocs\packer"?>New/service7.jpg" class="img-fluid" alt="">
										</span>
									</span>		
									<div class="pbminfotech-box-content">
										<div class="pbminfotech-box-content-inner">
											<div class="pbminfotech-pf-box-title">
												<div class="pbmit-ihbox-icon">
													<i class="pbmit-moversco-business-icon pbmit-moversco-business-icon-truck"></i>					
												</div>
												<h3>
													<a href="services-details.html">Moving Locally</a>
												</h3>
												<div class="pbminfotech-service-content">
													<p>Extreme attention to detail is the essence of Boo’s unique.</p>
												</div>
												<div class="pbminfotech-box-link">
													<a href="services-details.html">READ MORE</a>
												</div>
											</div>
										</div>
									</div>
								</div>
							</article>
						</div>
						<div class="col-md-6 col-lg-4">
							<article class="pbminfotech-servicebox-style-1">
								<div class="pbminfotech-post-item">
									<span class="pbminfotech-item-thumbnail">
										<span class="pbminfotech-item-thumbnail-inner">
											<img src="<?php $baseurl="C:\xampp\htdocs\packer"?>New/service8.jpg" class="img-fluid" alt="">
										</span>
									</span>		
									<div class="pbminfotech-box-content">
										<div class="pbminfotech-box-content-inner">
											<div class="pbminfotech-pf-box-title">
												<div class="pbmit-ihbox-icon">
													<i class="pbmit-moversco-business-icon pbmit-moversco-business-icon-world"></i>					
												</div>
												<h3>
													<a href="services-details.html">Trustworthy Service</a>
												</h3>
												<div class="pbminfotech-service-content">
													<p>Extreme attention to detail is the essence of Boo’s unique.</p>
												</div>
												<div class="pbminfotech-box-link">
													<a href="services-details.html">READ MORE</a>
												</div>
											</div>
										</div>
									</div>
								</div>
							</article>
						</div>
						<div class="col-md-6 col-lg-4">
							<article class="pbminfotech-servicebox-style-1">
								<div class="pbminfotech-post-item">
									<span class="pbminfotech-item-thumbnail">
										<span class="pbminfotech-item-thumbnail-inner">
											<img src="<?php $baseurl="C:\xampp\htdocs\packer"?>New/service9.jpg" class="img-fluid" alt="">
										</span>
									</span>		
									<div class="pbminfotech-box-content">
										<div class="pbminfotech-box-content-inner">
											<div class="pbminfotech-pf-box-title">
												<div class="pbmit-ihbox-icon">
													<i class="pbmit-moversco-business-icon pbmit-moversco-business-icon-parcel"></i>					
												</div>
												<h3>
													<a href="services-details.html">Transportation Service</a>
												</h3>
												<div class="pbminfotech-service-content">
													<p>Extreme attention to detail is the essence of Boo’s unique.</p>
												</div>
												<div class="pbminfotech-box-link">
													<a href="services-details.html">READ MORE</a>
												</div>
											</div>
										</div>
									</div>
								</div>
							</article>
						</div>
					</div>
				</div>
            </section>
            <!-- service End -->
			
		</div>
		<?php include 'footer.php';?>