<?php include 'header.php';?>
 <!-- Page Content -->
 <div class="page-content">

<!-- About Start -->
<section class="section-lgt">
    <div class="container">
        <div class="about-two-content">
            <h2>“I have found honest and reliable movers through <br> for each of my last seven moves”</h2>
        </div>
        <div class="about-two-single-img">
            <img src="<?php $baseurl="C:\xampp\htdocs\packer"?>images/moverrr.png" class="img-fluid" alt="">
        </div>
    </div>
</section>
<!-- About End --> 

<!-- Our Company Start -->
<section class="our-company-section-two">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-lg-6">
                <div class="our-company-two-box">
                    <div class="pbmit-heading-subheading">
                        <h4 class="pbmit-subtitle">OUR COMPANY</h4>
                        <h2 class="pbmit-title">We are the best moving company in the world.</h2>
                    </div>
                    <p>Now were up in the big leagues getting’ our turn at bat. And when the odds are against him and their dangers work to do Duis aute irure dolor.</p>
                    <div class="our-company-fidbox">
                        <div class="row">
                            <div class="col-md-6 pbmit-col-wrapper">
                                <div class="pbminfotech-fidbox-style-4">
                                    <div class="pbminfotech-fld-contents">
                                        <div class="pbminfotech-ihbox-icon pbminfotech-large-icon pbminfotech-icon-skincolor">
                                            <div class="pbminfotech-sbox-icon-wrapper">
                                                <i class="pbmit-moversco-business-icon pbmit-moversco-business-icon-smile-2"></i>
                                            </div>
                                        </div>
                                        <div class="pbminfotech-fld-contents-wrap">
                                            <div class="pbminfotech-fid-inner">			
                                                <span data-appear-animation="animateDigits" data-from="0" data-to="500" data-interval="5" class="numinate">500</span>
                                            </div>
                                            <h3 class="pbminfotech-fid-title">
                                                <span>Happy Customers<br></span>
                                            </h3>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 pbmit-col-wrapper">
                                <div class="pbminfotech-fidbox-style-4">
                                    <div class="pbminfotech-fld-contents">
                                        <div class="pbminfotech-ihbox-icon pbminfotech-large-icon pbminfotech-icon-skincolor">
                                            <div class="pbminfotech-sbox-icon-wrapper">
                                                <i class="pbmit-moversco-business-icon pbmit-moversco-business-icon-box"></i>
                                            </div>
                                        </div>
                                        <div class="pbminfotech-fld-contents-wrap">
                                            <div class="pbminfotech-fid-inner">			
                                                <span data-appear-animation="animateDigits" data-from="0" data-to="6540" data-interval="5" class="numinate">6,540</span>
                                            </div>
                                            <h3 class="pbminfotech-fid-title">
                                                <span>Total boxed moved<br></span>
                                            </h3>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-12 col-lg-6">
                <div class="our-company-two-bg">
                    <div class="our-company-two-img">
                        <img src="<?php $baseurl="C:\xampp\htdocs\packer"?>images/img-01.jpg" class="img-fluid" alt="">
                    </div>	
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Our Company End --> 

<!-- Icon Box Start --> 
<section class="ihbox-section-two">
    <div class="container">
        <div class="pbmit-heading-subheading text-center">
            <h4 class="pbmit-subtitle">WHY CHOOSE US</h4>
            <h2 class="pbmit-title">We give you complete control <br>of your shipments.</h2>
        </div>
        <div class="row">
            <div class="col-md-4">
                <div class="pbminfotech-ihbox-style-4"> 
                    <div class="pbminfotech-ihbox-inner">
                        <div class="pbminfotech-ihbox-icon pbminfotech-large-icon pbminfotech-icon-skincolor">
                            <div class="pbminfotech-ihbox-icon-wrapper pbminfotech-ihbox-icon-type-text">01</div>
                        </div>
                        <div class="pbminfotech-ihbox-contents pbminfotech">
                            <div class="pbminfotech-vc_general">
                                <div class="pbminfotech-vc_cta3_content-container">
                                    <div class="pbminfotech-vc_cta3-content">
                                        <div class="pbminfotech-vc_cta3-content-header pbminfotech-wrap">
                                            <div class="pbminfotech-vc_cta3-headers pbminfotech-wrap-cell">
                                                <h2 class="pbminfotech-custom-heading ">Request quotes</h2>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="pbminfotech-cta3-content-wrapper">Extreme attention to detail is the essence of Marwa Movers unique design concepts.</div>
                            <div class="pbminfotech-vc_btn3-container pbminfotech-vc_btn3-inline">
                                <a class="pbminfotech-vc_general" href="#" title="">READ MORE 
                                    <i class="pbminfotech-vc_btn3-icon fa fa-angle-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="pbminfotech-ihbox-style-4"> 
                    <div class="pbminfotech-ihbox-inner">
                        <div class="pbminfotech-ihbox-icon pbminfotech-large-icon pbminfotech-icon-skincolor">
                            <div class="pbminfotech-ihbox-icon-wrapper pbminfotech-ihbox-icon-type-text">02</div>
                        </div>
                        <div class="pbminfotech-ihbox-contents pbminfotech">
                            <div class="pbminfotech-vc_general">
                                <div class="pbminfotech-vc_cta3_content-container">
                                    <div class="pbminfotech-vc_cta3-content">
                                        <div class="pbminfotech-vc_cta3-content-header pbminfotech-wrap">
                                            <div class="pbminfotech-vc_cta3-headers pbminfotech-wrap-cell">
                                                <h2 class="pbminfotech-custom-heading ">Compare prices</h2>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="pbminfotech-cta3-content-wrapper">Extreme attention to detail is the essence of Marwa Movers unique design concepts.</div>
                            <div class="pbminfotech-vc_btn3-container pbminfotech-vc_btn3-inline">
                                <a class="pbminfotech-vc_general" href="#" title="">READ MORE 
                                    <i class="pbminfotech-vc_btn3-icon fa fa-angle-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="pbminfotech-ihbox-style-4"> 
                    <div class="pbminfotech-ihbox-inner">
                        <div class="pbminfotech-ihbox-icon pbminfotech-large-icon pbminfotech-icon-skincolor">
                            <div class="pbminfotech-ihbox-icon-wrapper pbminfotech-ihbox-icon-type-text">03</div>
                        </div>
                        <div class="pbminfotech-ihbox-contents pbminfotech">
                            <div class="pbminfotech-vc_general">
                                <div class="pbminfotech-vc_cta3_content-container">
                                    <div class="pbminfotech-vc_cta3-content">
                                        <div class="pbminfotech-vc_cta3-content-header pbminfotech-wrap">
                                            <div class="pbminfotech-vc_cta3-headers pbminfotech-wrap-cell">
                                                <h2 class="pbminfotech-custom-heading ">Safely delivered</h2>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="pbminfotech-cta3-content-wrapper">Extreme attention to detail is the essence of Marwa Movers unique design concepts.</div>
                            <div class="pbminfotech-vc_btn3-container pbminfotech-vc_btn3-inline">
                                <a class="pbminfotech-vc_general" href="#" title="">READ MORE 
                                    <i class="pbminfotech-vc_btn3-icon fa fa-angle-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Icon Box End --> 

<!-- Video Start --> 
<!-- <section class="video-section-two"> -->
    <!-- <div class="container"> -->
        <!-- <div class="video-two-button-bg"> -->
            <!-- <div class="video-two-play-button"> -->
                <!-- <span><i class="themifyicon ti-control-play"></i></span> -->
                <!-- <a class="pbmin-lightbox-video" href="https://www.youtube.com/watch?v=g-D0PE2XotQ"></a> -->
            <!-- </div> -->
        <!-- </div> -->
    <!-- </div> -->
<!-- </section> -->
<!-- Video End -->

<!-- Service Start --> 
<section class="section-md">
    <div class="container">
        <div class="pbmit-heading-subheading text-center">
            <h4 class="pbmit-subtitle">Our Services</h4>
            <h2 class="pbmit-title">We are a UAE based top <br>Marwa Movers company</h2>
        </div>
        <div class="row">
            <div class="col-md-6 col-lg-4">
                <article class="pbminfotech-servicebox-style-1">
                    <div class="pbminfotech-post-item">
                        <span class="pbminfotech-item-thumbnail">
                            <span class="pbminfotech-item-thumbnail-inner">
                                <img src="<?php $baseurl="C:\xampp\htdocs\packer"?>images/service1.jpg" class="img-fluid" alt="">
                            </span>
                        </span>		
                        <div class="pbminfotech-box-content">
                            <div class="pbminfotech-box-content-inner">
                                <div class="pbminfotech-pf-box-title">
                                    <div class="pbmit-ihbox-icon">
                                        <i class="pbmit-moversco-business-icon pbmit-moversco-business-icon-shipping-and-delivery-1"></i>					
                                    </div>
                                    <h3>
                                        <a href="services-details.html">Residential Moves</a>
                                    </h3>
                                    <div class="pbminfotech-service-content">
                                        <p>Extreme attention to detail is the essence of Boo’s unique.</p>
                                    </div>
                                    <div class="pbminfotech-box-link">
                                        <a href="services-details.html">READ MORE</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </article>
            </div>
            <div class="col-md-6 col-lg-4">
                <article class="pbminfotech-servicebox-style-1">
                    <div class="pbminfotech-post-item">
                        <span class="pbminfotech-item-thumbnail">
                            <span class="pbminfotech-item-thumbnail-inner">
                                <img src="<?php $baseurl="C:\xampp\htdocs\packer"?>images/service2.jpg" class="img-fluid" alt="">
                            </span>
                        </span>		
                        <div class="pbminfotech-box-content">
                            <div class="pbminfotech-box-content-inner">
                                <div class="pbminfotech-pf-box-title">
                                    <div class="pbmit-ihbox-icon">
                                        <i class="pbmit-moversco-business-icon pbmit-moversco-business-icon-headset-1"></i>					
                                    </div>
                                    <h3>
                                        <a href="services-details.html">Corporate Relocation</a>
                                    </h3>
                                    <div class="pbminfotech-service-content">
                                        <p>Extreme attention to detail is the essence of Boo’s unique.</p>
                                    </div>
                                    <div class="pbminfotech-box-link">
                                        <a href="services-details.html">READ MORE</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </article>
            </div>
            <div class="col-md-6 col-lg-4">
                <article class="pbminfotech-servicebox-style-1">
                    <div class="pbminfotech-post-item">
                        <span class="pbminfotech-item-thumbnail">
                            <span class="pbminfotech-item-thumbnail-inner">
                                <img src="<?php $baseurl="C:\xampp\htdocs\packer"?>images/service3.jpg" class="img-fluid" alt="">
                            </span>
                        </span>		
                        <div class="pbminfotech-box-content">
                            <div class="pbminfotech-box-content-inner">
                                <div class="pbminfotech-pf-box-title">
                                    <div class="pbmit-ihbox-icon">
                                        <i class="pbmit-moversco-business-icon pbmit-moversco-business-icon-house"></i>					
                                    </div>
                                    <h3>
                                        <a href="services-details.html">Warehousing & Storage</a>
                                    </h3>
                                    <div class="pbminfotech-service-content">
                                        <p>Extreme attention to detail is the essence of Boo’s unique.</p>
                                    </div>
                                    <div class="pbminfotech-box-link">
                                        <a href="services-details.html">READ MORE</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </article>
            </div>
        </div>
    </div>
   </section>
<!-- Service End -->

<!-- Counter Start  
<section class="section-lgb">
   /* <div class="container">
        <div class="row">
            <div class="col-md-12 col-lg-5">
                <div class="counter-two-content">
                    <div class="pbmit-heading-subheading">
                        <h4 class="pbmit-subtitle">Moving Safely</h4>
                        <h2 class="pbmit-title">We provide Safe Moving Procedures</h2>
                    </div>
                    <p>Now were up in the big leagues getting’ our turn at bat. And when the odds are against him and their dangers work to do Duis aute irure dolor coding skills required.</p>
                    <a href="about-us.html" class="pbmit-btn pbmit-btn-outline-global">READ MORE</a>
                </div>
            </div>
            <div class="col-md-12 col-lg-7">
                <div class="row">
                    <div class="col-md-6">
                        <div class="pbminfotech-fidbox-style-1 mt-4">
                            <div class="pbmit-fld-contents">
                                <div class="pbmit-circle-outer" data-digit="85" data-fill="#e32222" data-before="" data-before-type="sup" data-after="<sub>%</sub>" data-after-type="sub" data-size="160" data-emptyfill="#f3f3f3" data-thickness="7" data-gradient="">
                                    <div class="pbmit-circle-w">
                                        <div class="pbmit-circle">
                                        </div>
                                        <div class="pbmit-circle-overlay">
                                            <div class="pbmit-circle-number">85<sub>%</sub></div>
                                        </div>
                                    </div>
                                    <div class="pbmit-fid-title-w">
                                        <h3 class="pbmit-fid-title"><span>Customers Chooses us<br></span></h3>
                                        <div class="pbmit-fid-desc">Now were in the big leagues getting our turn at bat.</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="pbminfotech-fidbox-style-1 mt-4">
                            <div class="pbmit-fld-contents">
                                <div class="pbmit-circle-outer" data-digit="90" data-fill="#e32222" data-before="" data-before-type="sup" data-after="<sub>%</sub>" data-after-type="sub" data-size="160" data-emptyfill="#f3f3f3" data-thickness="7" data-gradient="">
                                    <div class="pbmit-circle-w">
                                        <div class="pbmit-circle">
                                        </div>
                                        <div class="pbmit-circle-overlay">
                                            <div class="pbmit-circle-number">90<sub>%</sub></div>
                                        </div>
                                    </div>
                                    <div class="pbmit-fid-title-w">
                                        <h3 class="pbmit-fid-title"><span>Customers are Satisfied<br></span></h3>
                                        <div class="pbmit-fid-desc">Now were in the big leagues getting our turn at bat.</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>-->
<!-- Counter End -->

<!-- Client Start 
<section class="client-section-two">
    <div class="container">
        <div class="row">
            <div class="col-lg-20percent">
                <div class="pbminfotech-client-logo-tooltip" data-tooltip="BrandName">
                    <div class="pbminfotech-clientbox-style-1">
                        <span class="pbminfotech-item-thumbnail">
                            <span class="pbminfotech-item-thumbnail-inner">
                                <img src="<?php $baseurl="C:\xampp\htdocs\packer"?>images/Client-01.png" class="img-fluid" alt="">
                            </span>
                        </span>	
                    </div>
                </div>
            </div>
            <div class="col-lg-20percent">
                <div class="pbminfotech-client-logo-tooltip" data-tooltip="Dynamic">
                    <div class="pbminfotech-clientbox-style-1">
                        <span class="pbminfotech-item-thumbnail">
                            <span class="pbminfotech-item-thumbnail-inner">
                                <img src="<?php $baseurl="C:\xampp\htdocs\packer"?>images/Client-02.png" class="img-fluid" alt="">
                            </span>
                        </span>	
                    </div>
                </div>
            </div>
            <div class="col-lg-20percent">
                <div class="pbminfotech-client-logo-tooltip" data-tooltip="Homemovers">
                    <div class="pbminfotech-clientbox-style-1">
                        <span class="pbminfotech-item-thumbnail">
                            <span class="pbminfotech-item-thumbnail-inner">
                                <img src="<?php $baseurl="C:\xampp\htdocs\packer"?>images/Client-03.png" class="img-fluid" alt="">
                            </span>
                        </span>	
                    </div>
                </div>
            </div>
            <div class="col-lg-20percent">
                <div class="pbminfotech-client-logo-tooltip" data-tooltip="BrandName">
                    <div class="pbminfotech-clientbox-style-1">
                        <span class="pbminfotech-item-thumbnail">
                            <span class="pbminfotech-item-thumbnail-inner">
                                <img src="<?php $baseurl="C:\xampp\htdocs\packer"?>images/Client-04.png" class="img-fluid" alt="">
                            </span>
                        </span>	
                    </div>
                </div>
            </div>
            <div class="col-lg-20percent">
                <div class="pbminfotech-client-logo-tooltip" data-tooltip="Techbrand">
                    <div class="pbminfotech-clientbox-style-1">
                        <span class="pbminfotech-item-thumbnail">
                            <span class="pbminfotech-item-thumbnail-inner">
                                <img src="<?php $baseurl="C:\xampp\htdocs\packer"?>images/Client-05.png" class="img-fluid" alt="">
                            </span>
                        </span>	
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>--> 
<!-- Client End -->

<!-- Appointment Start -->
<section class="appointment-section-two">
    <div class="container">
        <div class="row g-0">
            <div class="col-xl-5 col-lg-6">
                <div class="appointment-bg-two" data-aos="fade-up" data-aos-duration="8000">
                    <div class="pbmit-heading-subheading">
                        <h4 class="pbmit-subtitle">REQUEST A</h4>
                        <h2 class="pbmit-title text-white">Free Quote</h2>
                    </div>
                    <form class="form-style-1">
                        <div class="row"> 
                            <div class="col-md-12">
                                <input type="text" name="your-name" class="form-control" placeholder="Your Name">
                            </div>
                            <div class="col-md-6">
                                <input type="text" name="your-phone" class="form-control" placeholder="Move From">
                            </div>
                            <div class="col-md-6">
                                <input type="text" name="subject" class="form-control" placeholder="Move To">
                            </div>
                            <div class="col-md-12">
                                <textarea name="message" cols="40" rows="5" class="form-control" placeholder="Message"></textarea>
                            </div>
                            <div class="col-md-12">
                                <button type="submit" class="pbmit-btn pbmit-btn-hover-white">Send Message</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-xl-7 col-lg-12"></div>
        </div>
    </div>
</section>
<!-- Appointment End -->	

<!-- Team Start -->
<section class="team-section-two">	
    <div class="container"> 
        <div class="pbmit-heading-subheading text-center">
            <h1 class="pbmit-subtitle">Our Packing</h1>
            <!-- <h2 class="pbmit-title">Meet our Professionals</h2> -->
        </div>
        <div class="row">
            
        <div class="col-sm-6 col-lg-3">
                <article class="pbminfotech-teambox-style-2">
                    <div class="pbminfotech-post-item">
                        <span class="pbminfotech-item-thumbnail">
                            <span class="pbminfotech-item-thumbnail-inner">
                                <img src="<?php $baseurl="C:\xampp\htdocs\packer"?>New/one.jpg" class="img-fluid" alt="">
                            </span>
                        </span>		
                        <div class="pbminfotech-box-content">
                            <div class="pbminfotech-box-content-inner">
                                <div class="pbminfotech-pf-box-title">
                                    <div class="pbminfotech-box-title">
                                        
                                    </div>
                                </div>
                                <div class="pbminfotech-box-team-position"></div>
                                <div class="pbminfotech-teambox-social-links">
                                    <div class="pbminfotech-team-social-links-wrapper">
                                         
                                    </div>				
                                </div>
                            </div>
                        </div>
                    </div>
                </article>
            </div>
            <div class="col-sm-6 col-lg-3">
                <article class="pbminfotech-teambox-style-2">
                    <div class="pbminfotech-post-item">
                        <span class="pbminfotech-item-thumbnail">
                            <span class="pbminfotech-item-thumbnail-inner">
                                <img src="<?php $baseurl="C:\xampp\htdocs\packer"?>New/two.jpg" class="img-fluid" alt="">
                            </span>
                        </span>		
                        <div class="pbminfotech-box-content">
                            <div class="pbminfotech-box-content-inner">
                                <div class="pbminfotech-pf-box-title">
                                    <div class="pbminfotech-box-title">
                                        
                                    </div>
                                </div>
                                <div class="pbminfotech-box-team-position"></div>
                                <div class="pbminfotech-teambox-social-links">
                                    <div class="pbminfotech-team-social-links-wrapper">
                                    </div>				
                                </div>
                            </div>
                        </div>
                    </div>
                </article>
            </div>
            <div class="col-sm-6 col-lg-3">
                <article class="pbminfotech-teambox-style-2">
                    <div class="pbminfotech-post-item">
                        <span class="pbminfotech-item-thumbnail">
                            <span class="pbminfotech-item-thumbnail-inner">
                                <img src="<?php $baseurl="C:\xampp\htdocs\packer"?>New/ten.jpg" class="img-fluid" alt="">
                            </span>
                        </span>		
                        <div class="pbminfotech-box-content">
                            <div class="pbminfotech-box-content-inner">
                                <div class="pbminfotech-pf-box-title">
                                    <div class="pbminfotech-box-title">
                                        
                                    </div>
                                </div>
                                <div class="pbminfotech-box-team-position"></div>
                                <div class="pbminfotech-teambox-social-links">
                                    <div class="pbminfotech-team-social-links-wrapper">
                                       
                                    </div>				
                                </div>
                            </div>
                        </div>
                    </div>
                </article>
            </div>
            <div class="col-sm-6 col-lg-3">
                <article class="pbminfotech-teambox-style-2">
                    <div class="pbminfotech-post-item">
                        <span class="pbminfotech-item-thumbnail">
                            <span class="pbminfotech-item-thumbnail-inner">
                                <img src="<?php $baseurl="C:\xampp\htdocs\packer"?>New/resize.jpg" class="img-fluid" alt="">
                            </span>
                        </span>		
                        <div class="pbminfotech-box-content">
                            <div class="pbminfotech-box-content-inner">
                                <div class="pbminfotech-pf-box-title">
                                    <div class="pbminfotech-box-title">
                                        
                                    </div>
                                </div>
                                <div class="pbminfotech-box-team-position"></div>
                                <div class="pbminfotech-teambox-social-links">
                                    <div class="pbminfotech-team-social-links-wrapper">
                                       
                                    </div>				
                                </div>
                            </div>
                        </div>
                    </div>
                </article>
            </div>
            <div class="col-sm-6 col-lg-3">
                <article class="pbminfotech-teambox-style-2">
                    <div class="pbminfotech-post-item">
                        <span class="pbminfotech-item-thumbnail">
                            <span class="pbminfotech-item-thumbnail-inner">
                                <img src="<?php $baseurl="C:\xampp\htdocs\packer"?>New/five.jpg" class="img-fluid" alt="">
                            </span>
                        </span>		
                        <div class="pbminfotech-box-content">
                            <div class="pbminfotech-box-content-inner">
                                <div class="pbminfotech-pf-box-title">
                                    <div class="pbminfotech-box-title">
                                        
                                    </div>
                                </div>
                                <div class="pbminfotech-box-team-position"></div>
                                <div class="pbminfotech-teambox-social-links">
                                    <div class="pbminfotech-team-social-links-wrapper">
                                       
                                    </div>				
                                </div>
                            </div>
                        </div>
                    </div>
                </article>
            </div>
            <div class="col-sm-6 col-lg-3">
                <article class="pbminfotech-teambox-style-2">
                    <div class="pbminfotech-post-item">
                        <span class="pbminfotech-item-thumbnail">
                            <span class="pbminfotech-item-thumbnail-inner">
                                <img src="<?php $baseurl="C:\xampp\htdocs\packer"?>New/six.jpg" class="img-fluid" alt="">
                            </span>
                        </span>		
                        <div class="pbminfotech-box-content">
                            <div class="pbminfotech-box-content-inner">
                                <div class="pbminfotech-pf-box-title">
                                    <div class="pbminfotech-box-title">
                                        
                                    </div>
                                </div>
                                <div class="pbminfotech-box-team-position"></div>
                                <div class="pbminfotech-teambox-social-links">
                                    <div class="pbminfotech-team-social-links-wrapper">
                                        
                                    </div>				
                                </div>
                            </div>
                        </div>
                    </div>
                </article>
            </div>
            <div class="col-sm-6 col-lg-3">
                <article class="pbminfotech-teambox-style-2">
                    <div class="pbminfotech-post-item">
                        <span class="pbminfotech-item-thumbnail">
                            <span class="pbminfotech-item-thumbnail-inner">
                                <img src="<?php $baseurl="C:\xampp\htdocs\packer"?>New/seven.jpg" class="img-fluid" alt="">
                            </span>
                        </span>		
                        <div class="pbminfotech-box-content">
                            <div class="pbminfotech-box-content-inner">
                                <div class="pbminfotech-pf-box-title">
                                    <div class="pbminfotech-box-title">
                                        
                                    </div>
                                </div>
                                <div class="pbminfotech-box-team-position"></div>
                                <div class="pbminfotech-teambox-social-links">
                                    <div class="pbminfotech-team-social-links-wrapper">
                                        
                                    </div>				
                                </div>
                            </div>
                        </div>
                    </div>
                </article>
            </div>
            <div class="col-sm-6 col-lg-3">
                <article class="pbminfotech-teambox-style-2">
                    <div class="pbminfotech-post-item">
                        <span class="pbminfotech-item-thumbnail">
                            <span class="pbminfotech-item-thumbnail-inner">
                                <img src="<?php $baseurl="C:\xampp\htdocs\packer"?>New/onee.jpg" class="img-fluid" alt="">
                            </span>
                        </span>		
                        <div class="pbminfotech-box-content">
                            <div class="pbminfotech-box-content-inner">
                                <div class="pbminfotech-pf-box-title">
                                    <div class="pbminfotech-box-title">
                                        
                                    </div>
                                </div>
                                <div class="pbminfotech-box-team-position"></div>
                                <div class="pbminfotech-teambox-social-links">
                                    <div class="pbminfotech-team-social-links-wrapper">
                                        
                                    </div>				
                                </div>
                            </div>
                        </div>
                    </div>
                </article>
            </div>
        </div>
    </div>
</section>
<!-- Team End -->

<!-- Get Started Start 
<section class="get-started-section-two">
    <div class="container pe-0">
        <div class="get-started-bg-two">
            <div class="row">
                <div class="col-md-8">
                    <div class="pbmit-heading-subheading text-white mb-0">
                        <h4 class="pbmit-subtitle">get started</h4>
                        <h2 class="pbmit-title">Helping Over 50,000 Movers in the USA</h2>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="get-started-button"> 
                        <a href="#" class="pbmit-btn pbmit-btn-white">DISCOVER MORE</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>-->
<!-- Get Started End -->

<!-- Blog Start 
<section class="pbmit-bg-color-light blog-section-two">
   <div class="container">
        <div class="pbmit-heading-subheading text-center">
            <h4 class="pbmit-subtitle">Our blog</h4>
            <h2 class="pbmit-title">Our Happy Customer Say</h2>
        </div>
        <div class="row">
            <div class="col-md-6">
                <article class="pbminfotech-box-blog pbminfotech-blogbox-style-1">
                    <div class="post-item">
                        <div class="pbminfotech-blog-image-with-meta">
                            <div class="pbminfotech-featured-wrapper pbminfotech-post-featured-wrapper pbminfotech-post-format-">
                                <img src="<?php $baseurl="C:\xampp\htdocs\packer"?>images/blog-01.jpg" class="img-fluid" alt="">
                            </div>
                        </div>
                        <div class="pbminfotech-box-content">
                            <div class="pbminfotech-meta-date"><span>Aug</span>08</div>
                            <div class="pbminfotech-box-title">
                                <h4><a href="blog-single-view.html">Our Home Entertainment has Evolved Significantly</a></h4>
                            </div>
                            <div class="pbmit-blogbox-readmore">
                                <div class="pbminfotech-blogbox-footer-left">
                                    <a href="blog-single-view.html">Read More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </article>
            </div>
            <div class="col-md-6">
                <div class="row">
                    <div class="col-md-12">
                        <article class="pbminfotech-box-blog pbminfotech-blogbox-style-2 pbminfotech-blogbox-format-gallery">
                            <div class="post-item clearfix">
                                <div class="col-md-4 col-sm-4 pbminfotech-box-img-left">
                                    <div class="pbminfotech-featured-wrapper pbminfotech-post-featured-wrapper pbminfotech-post-format-">
                                        <div class="swiper-slider" data-loop="false" data-autoplay="true" data-dots="true" data-arrows="false"  data-columns="1" data-margin="0" data-effect="slide">
                                            <div class="swiper-wrapper">
                                                <div class="swiper-slide">                           
                                                    <!-- Slide1 
                                                    <img src="<?php $baseurl="C:\xampp\htdocs\packer"?>images/blog-1.jpg" class="img-fluid" alt="">
                                                </div>
                                                <div class="swiper-slide">                           
                                                    <!-- Slide2 
                                                    <img src="<?php $baseurl="C:\xampp\htdocs\packer"?>images/blog-2.jpg" class="img-fluid" alt="">
                                                </div>
                                                <div class="swiper-slide">                           
                                                    <!-- Slide3 
                                                    <img src="<?php $baseurl="C:\xampp\htdocs\packer"?>images/blog-3.jpg" class="img-fluid" alt="">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="pbminfotech-box-content col-md-8 col-sm-8">
                                    <div class="pbminfotech-box-content-inner">
                                        <div class="pbmit-featured-meta-wrapper pbmit-featured-overlay">
                                            <div class="pbminfotech-meta-date"><span>Aug</span>15</div>
                                        </div>
                                        <div class="pbminfotech-box-title">
                                            <h4><a href="blog-single-view.html">Load Boards Show Flat Demand and Higher Rates</a></h4>
                                        </div>
                                        <div class="pbmit-blogbox-readmore">
                                            <div class="pbminfotech-blogbox-footer-left">
                                                <a href="blog-single-view.html">Read More</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </article>
                        <article class="pbminfotech-box-blog pbminfotech-blogbox-style-2">
                            <div class="post-item clearfix">
                                <div class="col-md-4 col-sm-4 pbminfotech-box-img-left">
                                    <div class="pbminfotech-featured-wrapper pbminfotech-post-featured-wrapper pbminfotech-post-format-">
                                        <img src="<?php $baseurl="C:\xampp\htdocs\packer"?>images/blog-4.jpg" class="img-fluid" alt="">
                                    </div>
                                </div>
                                <div class="pbminfotech-box-content col-md-8 col-sm-8">
                                    <div class="pbminfotech-box-content-inner">
                                        <div class="pbmit-featured-meta-wrapper pbmit-featured-overlay">
                                            <div class="pbminfotech-meta-date"><span>Sep</span>23</div>
                                        </div>
                                        <div class="pbminfotech-box-title">
                                            <h4><a href="blog-single-view.html">Truckers to Seek HOS Waiver to the Ease   Calif</a></h4>
                                        </div>
                                        <div class="pbmit-blogbox-readmore">
                                            <div class="pbminfotech-blogbox-footer-left">
                                                <a href="blog-single-view.html">Read More</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </article>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>-->
<!-- Blog End -->

</div>
<?php include 'footer.php';?>