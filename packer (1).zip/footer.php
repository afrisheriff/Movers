 <!-- footer -->
 <footer class="footer site-footer pbmit-bg-color-secondary">
			<div class="pbmit-footer-widget-area-top">
				<div class="container">
					<div class="row">
						<div class="col-md-4">
							<div class="pbmit-footer-boxes">
								<div class="pbmit-footer-contact-info">
                                    <div class="pbmit-footer-contact-info-inner">
                                       <i class="themifyicon ti-headphone"></i>
                                    </div>
									<div class="pbmit-footer-contact-info-wrap">
										<strong>Phone:</strong> <br>+971 50 200 2628
									</div>
                                </div>
							</div>
						</div>
						<div class="col-md-4">
							<div class="pbmit-footer-boxes">
								<div class="pbmit-footer-contact-info">
                                    <div class="pbmit-footer-contact-info-inner">
                                       	<i class="themifyicon ti-location-pin"></i>
                                    </div>
									<div class="pbmit-footer-contact-info-wrap">
										<strong>Address:</strong> <br>4578 Marmora Road
									</div>
                                </div>
							</div>
						</div>
						<div class="col-md-4">
							<div class="pbmit-footer-boxes">
								<div class="pbmit-footer-contact-info">
                                    <div class="pbmit-footer-contact-info-inner">
                                      	 <i class="themifyicon ti-email"></i>
                                    </div>
									<div class="pbmit-footer-contact-info-wrap">
										<strong>E-mail: 
									</div>
                                </div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="pbmit-footer-widget-area">
				<div class="container">
					<div class="row">
						<div class="col-md-6 col-lg-3">
							<div class="widget">
								<div class="textwidget">
									<p>
										<img class="pbmit-footerlogo" src="images/MOVE.png" alt="">
									</p>
									<p>The Marwa Movers and Packers are the leading movers in UAE. Yes, we are a renowned name whenever there is a talk about the best movers in UAE.</p>
								</div>
								<div class="pbmit-social-links-wrapper">
									<ul class="social-icons">
										<li class="pbmit-social-facebook">
											<a class=" tooltip-top" target="_blank" href="#">
												<i class="pbmit-base-icon-facebook"></i>
											</a>
										</li>
										<li class="pbmit-social-twitter">
											<a class=" tooltip-top" target="_blank" href="#">
												<i class="pbmit-base-icon-twitter"></i>
											</a>
										</li>
										<li class="pbmit-social-flickr">
											<a class=" tooltip-top" target="_blank" href="#">
												<i class="pbmit-base-icon-flickr"></i>
											</a>
										</li>
										<li class="pbmit-social-gplus">
											<a class=" tooltip-top" target="_blank" href="#">
												<i class="pbmit-base-icon-gplus"></i>
											</a>
										</li>
									</ul>
								</div>
							</div>
						</div>
						<div class="col-md-6 col-lg-3">
							<div class="widget">
							<h2 class="widget-title">QUICK LINKS</h2>
							<div class="textwidget">
								<ul>
									<li><a href="#">About Us</a></li>
									<li><a href="#">Our Services</a></li>
									<li><a href="#">Get In Touch</a></li>
									<li><a href="#">Our Clients</a></li>
									<li><a href="#">Download Broucher</a></li>
								</ul>
							</div>
							</div>
						</div>
						<div class="col-md-6 col-lg-3">
							<div class="widget">
								<h2 class="widget-title">CATEGORIES</h2>
								<div class="textwidget">
									<ul>
										<li><a href="#">Express</a></li>
										<li><a href="#">Material</a></li>
										<li><a href="#">Furniture</a></li>
										<li><a href="#">Vehicle</a></li>
										<li><a href="#">Commodity</a></li>
									</ul>
								</div>
							</div>
						</div>
						<div class="col-md-6 col-lg-3">
							<div class="widget">
								<h2 class="widget-title">NEWSLETTER</h2>
								<div class="textwidget">
									<div>Accusamus et iusto odio praesentium quas molestias except.</div>
									<form>
										<input type="email" name="email" placeholder="Your email address" required="">
										<button class="pbmit-btn" type="submit">Subscribe</button>
									</form>					
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="pbmit-footer-bottom">
				<div class="container">
					<div class="pbmit-footer-text-inner text-center">
						<div class="row">
							<div class="col-md-12">
								<div class="pbmit-footer-copyright-text-area"> Copyright © 2023 
									<a href="index.html">Marwa Movers</a>. All rights reserved.				
								</div>
							</div>			
						</div>
					</div>	
				</div>
			</div>	
		</footer>
		<!-- footer End -->

	</div>
	<!-- page wrapper End -->

	<!-- Search Box Start Here -->
	<div class="pbmit-search-overlay">
		<div class="pbmit-icon-close"></div>
		<div class="pbmit-search-outer"> 
			<form class="pbmit-site-searchform">
				<input type="search" class="form-control field searchform-s" name="s" placeholder="WRITE SEARCH WORD...">
				<button type="submit">
					<i class="pbmit-base-icon-search"></i>
				</button>
			</form>
		</div>
	</div>
   	<!-- Search Box End Here -->

      <!-- JS
         ============================================ -->
      <!-- jQuery JS -->
      <script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="js/jquery.min.js"></script>
      <!-- Popper JS -->
      <script src="js/popper.min.js"></script>
      <!-- Bootstrap JS -->
      <script src="js/bootstrap.min.js"></script> 
      <!-- jquery Waypoints JS -->
      <script src="js/jquery.waypoints.min.js"></script>
      <!-- jquery Appear JS -->
      <script src="js/jquery.appear.js"></script>
      <!-- Numinate JS -->
      <script src="js/numinate.min.js"></script>
      <!-- Swiper JS -->
      <script src="js/swiper.min.js"></script>
      <!-- Magnific JS -->
      <script src="js/jquery.magnific-popup.min.js"></script>
      <!-- Circle Progress JS -->
      <script src="js/circle-progress.js"></script>  
      <!-- AOS -->
      <script src="js/aos.js"></script>
      <!-- Scripts JS -->
      <script src="js/scripts.js"></script>        
      <!-- Revolution JS -->
      <script src="revolution/rslider.js"></script>
      <script src="revolution/rbtools.min.js"></script>
      <script src="revolution/rs6.min.js"></script> 
   <script defer src="https://static.cloudflareinsights.com/beacon.min.js/v8b253dfea2ab4077af8c6f58422dfbfd1689876627854" integrity="sha512-bjgnUKX4azu3dLTVtie9u6TKqgx29RBwfj3QXYt5EKfWM/9hPSAI/4qcV5NACjwAo8UtTeWefx6Zq5PHcMm7Tg==" data-cf-beacon='{"rayId":"7f0cd8374f934df8","version":"2023.7.0","r":1,"token":"125856bf84ab44059737e93b01aa0fef","si":100}' crossorigin="anonymous"></script>
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">

</body>
</html>